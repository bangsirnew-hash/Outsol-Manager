OUTSOLE MANAGER 2.0 - proyek APK (Capacitor)
1. Buat repository baru di GitHub, unggah SEMUA isi folder ini (termasuk folder .github).
2. Buka tab "Actions" -> workflow "Build APK" jalan otomatis (sekitar 5-10 menit). Bisa juga klik "Run workflow".
3. Setelah hijau, buka run tersebut -> bagian "Artifacts" -> unduh "outsole-manager-apk" (ZIP berisi app-debug.apk).
4. Kirim APK ke HP, buka, izinkan "pasang dari sumber tidak dikenal".
Catatan: ini APK debug (cukup untuk dipakai sendiri). Untuk Play Store perlu build release bertanda tangan.
Data lama: Backup JSON di versi lama, lalu Pulihkan di aplikasi ini.
